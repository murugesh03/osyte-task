export const debounce = (cb, dealy = 1000) => {
  let timer;
  return function (...args) {
    const context = this;
    console.log(context, "this is context");
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      timer = null;
      cb.apply(context, args);
    }, dealy);
  };
};
