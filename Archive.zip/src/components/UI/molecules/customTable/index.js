import React from "react";
import { useTable, usePagination } from "react-table";
import Pagination from "../../atoms/pagination";
import Table from "../../atoms/table";

const CustomTable = ({
  columns,
  data,
  totalResults,
  pageNumber,
  setPageNumber,
}) => {
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
    page,
    canPreviousPage,
    canNextPage,
    pageOptions,
    pageCount,
    gotoPage,
    nextPage,
    previousPage,
    setPageSize,
    changePage,
    state: { pageIndex, pageSize },
  } = useTable(
    {
      columns,
      data,
      initialState: {
        pageIndex: 1,
        pageSize: 20,
      },
      manualPagination: true,
      pageCount: Math.ceil(totalResults / 20),
    },
    usePagination
  );
  return (
    <>
      <Table
        getTableProps={getTableProps}
        getTableBodyProps={getTableBodyProps}
        page={page}
        prepareRow={prepareRow}
        headerGroups={headerGroups}
      />
      <Pagination
        setPageNumber={setPageNumber}
        gotoPage={gotoPage}
        pageNumber={pageNumber}
        pageCount={pageCount}
        pageIndex={pageIndex}
      />
    </>
  );
};

export default CustomTable;
