import React from "react";

const Pagination = ({
  setPageNumber,
  gotoPage,
  pageNumber,
  pageCount,
  pageIndex,
}) => {
  return (
    <div className="pagination">
      <button
        onClick={() => setPageNumber(Math.max(1, pageNumber - 1))}
        disabled={pageNumber === 1}
      >
        {"<"}
      </button>{" "}
      <button
        onClick={() => setPageNumber(Math.min(pageCount, pageNumber + 1))}
        disabled={pageCount === pageNumber}
      >
        {">"}
      </button>{" "}
      <span>
        Page{" "}
        <strong>
          {pageNumber} of {pageCount}
        </strong>{" "}
      </span>
      <span>
        | Go to page:{" "}
        <input
          type="number"
          defaultValue={pageIndex + 1}
          onChange={(e) => {
            const page = e.target.value ? Number(e.target.value) - 1 : 0;
            gotoPage(page);
          }}
          style={{ width: "100px" }}
        />
      </span>{" "}
    </div>
  );
};

export default Pagination;
