import axios from "axios";
import React, { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useQuery } from "react-query";
import styled from "styled-components";
import { useTable, usePagination } from "react-table";
import moment from "moment";
import { Spinner } from "@blueprintjs/core";
import debounce from "lodash.debounce";

import { useMovieStore } from "../../../store";
import CustomTable from "../../UI/molecules/customTable";

const Styles = styled.div`
  padding: 1rem;
  table {
    width: 100%;
    tr {
      td {
        text-align: center;
      }
    }
    th,
    td {
      margin: 0;
      padding: 0.5rem;
    }
  }
  .pagination {
    padding: 0.5rem;
    text-align: center;
  }
`;

function Table({ columns, data, totalResults, pageNumber, setPageNumber }) {
  // Use the state and functions returned from useTable to build your UI
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
    page,
    canPreviousPage,
    canNextPage,
    pageOptions,
    pageCount,
    gotoPage,
    nextPage,
    previousPage,
    setPageSize,
    changePage,
    state: { pageIndex, pageSize },
  } = useTable(
    {
      columns,
      data,
      initialState: {
        pageIndex: 1,
        pageSize: 20,
      },
      manualPagination: true,
      pageCount: Math.ceil(totalResults / 20),
    },
    usePagination
  );

  return (
    <>
      <table {...getTableProps()}>
        <thead>
          {headerGroups.map((headerGroup) => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map((column) => (
                <th {...column.getHeaderProps()}>{column.render("Header")}</th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {page.map((row, i) => {
            prepareRow(row);
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map((cell) => {
                  return (
                    <td {...cell.getCellProps()}>{cell.render("Cell")}</td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>

      <div className="pagination">
        <button
          onClick={() => setPageNumber(Math.max(1, pageNumber - 1))}
          disabled={pageNumber === 1}
        >
          {"<"}
        </button>{" "}
        <button
          onClick={() => setPageNumber(Math.min(pageCount, pageNumber + 1))}
          disabled={pageCount === pageNumber}
        >
          {">"}
        </button>{" "}
        <span>
          Page{" "}
          <strong>
            {pageNumber} of {pageCount}
          </strong>{" "}
        </span>
        <span>
          | Go to page:{" "}
          <input
            type="number"
            defaultValue={pageIndex + 1}
            onChange={(e) => {
              const page = e.target.value ? Number(e.target.value) - 1 : 0;
              gotoPage(page);
            }}
            style={{ width: "100px" }}
          />
        </span>{" "}
      </div>
    </>
  );
}
const getAllMovies = (page = 1) => {
  return axios.get(
    `${process.env.REACT_APP_BASE_URL}movie/top_rated?api_key=${process.env.REACT_APP_API_KEY}&language=en-US&page=${page}`
  );
};

const Home = () => {
  const [currentPage, setCurrentPage] = useState(1);

  const { isLoading, data, refetch } = useQuery(
    ["repoData", currentPage],
    () => getAllMovies(currentPage),
    {
      keepPreviousData: true,
      enabled: false,
    }
  );

  useEffect(() => {
    refetch();
  }, [currentPage]);

  const storeMovies = useMovieStore((state) => state.storeNewMovies);

  const columns = useMemo(() => [
    {
      Header: "Movie Image",
      accessor: "poster_path_full",
      Cell: ({ cell: { value } }) => (
        <img src={value} width={100} alt={value} />
      ),
    },
    {
      Header: "Movie Title",
      accessor: "title",
    },
    {
      Header: "Release Date",
      accessor: "release_date",
      Cell: ({ cell: { value } }) => <span>{moment(value).format("LL")}</span>,
    },
    {
      Header: "Language",
      accessor: "original_language",
    },
    {
      Header: "Rating",
      accessor: "vote_average",
      Cell: ({ cell: { value } }) => <span>{value}/10</span>,
    },
  ]);

  useEffect(() => {
    if (!!data?.data?.results.length) {
      storeMovies(changeMovieData(data.data.results));
    }
  }, [data]);

  const changeMovieData = (data) => {
    let revisedMovieData = data.map((ele) => {
      return {
        ...ele,
        poster_path_full: `${process.env.REACT_APP_IMAGE_URL}${ele.poster_path}`,
      };
    });

    return revisedMovieData;
  };
  return (
    <>
      {isLoading ? (
        <div
          style={{
            display: "block",
            width: 500,
            padding: 30,
          }}
        >
          <Spinner size={30} />
        </div>
      ) : (
        data?.data?.results.length && (
          <div className="container">
            <Styles>
              <CustomTable
                columns={columns}
                data={changeMovieData(data.data.results)}
                totalResults={data.data.total_results}
                pageNumber={currentPage}
                setPageNumber={setCurrentPage}
              />
            </Styles>
          </div>
        )
      )}
    </>
  );
};

export default Home;
